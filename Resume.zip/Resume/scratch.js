<div class = "list-container">
    <p>Libraries/Tools/Frameworks</p>
    </div>
    <div class = "list-container">
    <p>Software & Technologies</p>
    </div>


    <ul class="list-group">
    <li class = "list-group-item">Javascript</li>
    <li class = "list-group-item">HTML5</li>
    <li class = "list-group-item">C#</li>
<li class = "list-group-item">CSS3</li>
    </ul>


    <ul class="list-group">
    <li class = "list-group-item">JQuery</li>
    <li class = "list-group-item">Node.js</li>
    <li class = "list-group-item">Knockout.js</li>
    <li class = "list-group-item">.Net</li>
</ul>


<ul class="list-group">
    <li class = "list-group-item">Entity Framework</li>
<li class = "list-group-item">NUnit</li>
    <li class = "list-group-item">Mocha</li>
    </ul>


    <ul class="list-group">
    <li class = "list-group-item">Sql</li>
    <li class = "list-group-item">PostGre</li>
    <li class = "list-group-item">CouchDB</li>
    <li class = "list-group-item">Subversion</li>
    <li class = "list-group-item">GIT</li>
    </ul>

    <ul class="list-group">
    <li class = "list-group-item">Cloudwatch</li>
    <li class = "list-group-item">Cognito</li>
    <li class = "list-group-item">EC2</li>
    <li class = "list-group-item">RDS</li>
    <li class = "list-group-item">SCRUM</li>
    </ul>


    <div class = "row">
    <div class = "col column-header">Languages</div>
    <div class = "col column-header">Libraries/Tools/Frameworks</div>
    <div class = "col column-header">Software & Technologies</div>
    </div>
    <div class = "row skill-content">
    <div class = "col">
    Javascript, HTML5, C#, CSS3
</div>
<div class = "col">
    JQuery, Node.js, Knockout.js, .NET, Entity Framework, NUnit, Mocha
</div>
<div class = "col">
    SQL, PostGre, CouchDB, Subversion, GIT, CloudWatch, Cognito, EC2, RDS, SCRUM
</div>
</div>